<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->string('email')->unique();
            $table->enum('role', ['writer', 'admin'])->default('writer'); // admin
            $table->text('about')->nullable();
            $table->text('age')->nullable();
            $table->text('phoneNumber')->nullable();
            $table->text('address')->nullable();
            $table->text('careerChoice')->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->text('jobHistory')->nullable();
            $table->text('skill')->nullable();
            $table->text('education')->nullable();
            $table->text('image')->nullable(); 
            //$table->timestamp('blocked_date')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
