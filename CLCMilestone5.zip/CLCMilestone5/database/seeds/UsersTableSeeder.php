<?php

use App\User;

use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    // To automatically insert an admin to the table(use command in terminal)
    public function run()
    {
        $user = User::where('email', 'joe@gmail.com')->first();
        
        if(!$user){
            User::create([
                'name'=>'AlexCarrillo',
                'email'=>'alexcar@yahoo.com',
                'role'=>'admin',
                'password'=>Hash::make('password')
           ]);
        }
    }
}
