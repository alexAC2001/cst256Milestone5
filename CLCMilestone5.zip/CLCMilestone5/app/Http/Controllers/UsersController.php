<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 21th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44

// IMPORTANT

namespace App\Http\Controllers;

use App\Job;
use App\User;
use App\Http\Requests\Users\SubmitPortfolioRequest;
use App\Http\Requests\Users\UpdateProfileRequest;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class UsersController extends Controller
{
    
    // This method displays a page with all the users for the admin
    public function index()
    {
        return view('users.index')->with('users', User::all());       
    }
    
 
    // Method for editing user
    public function edit()
    {
        // Authenticate the user so no one else can edit them
        return view('users.edit')->with('user', auth()->user());
    }
    
    // Method applying the user's updated information
    public function update(UpdateProfileRequest $request)
    {
        $user = auth()->user();
        
        $user->update([
            
            'name' => $request->name,
            'about' => $request->about,
            'age' => $request->age,
            'phoneNumber' => $request->phoneNumber,
            'address' => $request->address,
            'careerChoice' => $request->careerChoice,
            
        ]);
                
        session()->flash('success', 'User updated successfully.');
        
        return redirect()->back();
        
    }
    
    // Allows an admin to make a user an admin
    public function makeAdmin(User $user)
    {
        $user->role = 'admin';
        
        $user->save();
        
        session()->flash('success', 'User made admin successfully.');
        
        return redirect(route('users.index'));
    }
    
    // For Admin to delete a user
    public function destroy($id)
    {
        // delete
        $user = user::find($id);
        $user->delete();
        
        // Redirect
        //Session::flash('message', 'Successfully deleted the job');
        return Redirect::to('users.index');
    }
    
    // Method for creating user portfolio
    public function portfolio()
    {
        // Authenticate the user so no one else can edit them
        return view('users.portfolio')->with('user', auth()->user());
    }
    
    // Method to upload portfolio
    public function uploadPortfolio(SubmitPortfolioRequest $request)
    {
        $user = auth()->user();
        
        $user->update([
            
            'jobHistory' => $request->jobHistory,
            'skill' => $request->skill,
            'education' => $request->education,
            'image' => $request->image,
        ]);
        
        session()->flash('success', 'User submitted their portfolio');
        
        return redirect()->back();        
    }    
    // This method displays a page with all the users for the admin
    public function otherPortfolios()
    {
        return view('otherPortfolios')->with('users', User::all());
    }
    
    // Method for creating user portfolio
    public function affinityGroups()
    {
        // Authenticate the user so no one else can edit them
        return view('groups.list')->with('user', auth()->user());
    }    
    
    
}
